# Name-Beautifier-Project
## The project is basically to beautify names or words. When you type your name into the text field and you click on the "change my name button", it will change the color of the text automatically.
# NB: randomColor was inmported using the npm command.
